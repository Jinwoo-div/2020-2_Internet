function over(obj) {
    obj.src = "sample2.jpg";
}
function out(obj) {
    obj.src = "sample.jpg";
}